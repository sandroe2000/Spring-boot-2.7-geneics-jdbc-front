package br.com.arrowdata.generic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenericApplicationTests {

	@Test
	void contextLoads() {
	}

}
