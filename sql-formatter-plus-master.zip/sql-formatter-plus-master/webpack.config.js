module.exports = {
  output: {
    library: 'sqlFormatter',
    libraryTarget: 'umd'
  }
};
